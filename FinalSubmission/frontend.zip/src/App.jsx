import { BrowserRouter as Router, Routes, Route, useNavigate } from "react-router-dom"; // Importing necessary modules from react-router-dom for routing and navigation
import { useEffect } from 'react'; // Importing the useEffect hook for side effects

// Importing components
import Register from "./components/Register";
import Login from "./components/Login";
import Home from "./components/Home";
import BookManagement from './components/BookManagement';
import MemberPortal from './components/MemberPortal'; 
import UserManagement from "./components/UserManagement"; // Import Users component
import AdminPortal from "./components/AdminPortal"; // Import AdminPortal component

// Main App component that wraps everything inside a Router
function App() {
  return (
    <Router> {/* The Router component is used to define the routing context */}
      <Main /> {/* The Main component is rendered inside the Router */}
    </Router>
  );
}

// Main component that handles the actual routing logic and redirection
function Main() {
  const navigate = useNavigate(); // Using useNavigate hook for programmatic navigation

  // useEffect hook to run side effects on component mount
  useEffect(() => {
    // Checking if the current path is the root ("/")
    if (window.location.pathname === '/') {
      navigate('/home'); // If at the root URL, redirect to "/home"
    }
  }, [navigate]); // The useEffect hook depends on the 'navigate' function


  return (
    <div className="container">
      <h1>Letian's Library Management System</h1>
      <Routes> {/* The Routes component is used to define the different routes */}
        {/* Defining route paths and their corresponding components */}
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/home" element={<Home />} /> 
        <Route path="/book-management" element={<BookManagement />} />
        <Route path="/member-portal" element={<MemberPortal />} />  
        <Route path="/user-management" element={<UserManagement />} />
        <Route path="/admin-portal" element={<AdminPortal />} />
      </Routes>
    </div>
  );
}

export default App;
