import { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate

function Register() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [userName, setUserName] = useState(""); // New state for userName
    const [userAddress, setUserAddress] = useState(""); // New state for userAddress
    const [userContactNumber, setUserContactNumber] = useState(""); // New state for userContactNumber
    const [errorMessage, setErrorMessage] = useState(""); // New state for error message

    // Initialize useNavigate hook
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Validate password length
        if (password.length < 6) {
            setErrorMessage("Password must be at least 6 characters long.");
            return;
        }
        
        // Reset the error message if validation passes
        setErrorMessage("");
        
        const response = await fetch("http://localhost:8080/api/users/register", {  
            method: "POST",
            headers: { "Content-Type": "application/json" },
            // Send user details in the body
            body: JSON.stringify({
                userEmail: email,
                userPassword: password,
                userName: userName, // Send userName
                userAddress: userAddress, // Send userAddress
                userContactNumber: userContactNumber, // Send userContactNumber
            }), 
        });
    
        if (response.ok) {
            alert("Registration successful");
            // Redirect to login page after successful registration
            navigate("/login");
        } else {
            const errorData = await response.json(); // Fetch error message if available
            alert(`Error registering: ${errorData.message || "Unknown error"}`);
        }
    };

    return (
        <form className="form" onSubmit={handleSubmit}>
            {errorMessage && <div className="error-message">{errorMessage}</div>} {/* Display error message */}
            <input type="text" value={userName} onChange={(e) => setUserName(e.target.value)} placeholder="Full Name" required />
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" required />
            <input type="text" value={userAddress} onChange={(e) => setUserAddress(e.target.value)} placeholder="Address"  />
            <input type="text" value={userContactNumber} onChange={(e) => setUserContactNumber(e.target.value)} placeholder="Contact Number"  />
            <button type="submit">Register</button>
        </form>
    );
}

export default Register;
