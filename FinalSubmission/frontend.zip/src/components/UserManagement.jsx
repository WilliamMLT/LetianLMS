import { useEffect, useState } from "react"; 
import axios from "axios";
import './UserManagement.css'; // Import the UserManagement-specific CSS file

const UserManagement = () => {
    const [users, setUsers] = useState([]);
    const [filteredUsers, setFilteredUsers] = useState([]); // Filtered users list
    const [errorMessage, setErrorMessage] = useState("");
    const [searchTerm, setSearchTerm] = useState({
        userName: "",
        userEmail: "",
        userRoles: ""
    });

    const [newUser, setNewUser] = useState({
        userName: "",
        userEmail: "",
        userAddress: "",
        userContactNumber: "",
        userPassword: "",
        userRoles: "member"
    });

    const [editingUser, setEditingUser] = useState(null); // Track which user is being edited

    useEffect(() => {
        fetchUsers();
    }, []);

    useEffect(() => {
        // Apply the filter whenever the searchTerm changes
        const filtered = users.filter(user =>
            user.userName.toLowerCase().includes(searchTerm.userName.toLowerCase()) &&
            user.userEmail.toLowerCase().includes(searchTerm.userEmail.toLowerCase()) &&
            user.userRoles.toLowerCase().includes(searchTerm.userRoles.toLowerCase())
        );
        setFilteredUsers(filtered);
    }, [searchTerm, users]);

    // Fetch users from the backend
    const fetchUsers = () => {
        axios.get("http://localhost:8080/api/users/all")
            .then(response => {
                setUsers(response.data);
                setFilteredUsers(response.data); // Initialize filtered users
            })
            .catch(error => console.error("Error fetching users:", error));
    };

    // Handle input changes for user search
    const handleSearchChange = (e) => {
        const { name, value } = e.target;
        setSearchTerm(prev => ({ ...prev, [name]: value }));
    };

    // Handle input changes for adding or editing users
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (editingUser) {
            setEditingUser(prevUser => ({ ...prevUser, [name]: value }));
        } else {
            setNewUser(prevUser => ({ ...prevUser, [name]: value }));
        }
    };

    // Add a new user
    const handleAddUser = () => {
        axios.post("http://localhost:8080/api/users/register", newUser)
            .then(() => {
                fetchUsers();
                setNewUser({ userName: "", userEmail: "", userAddress: "", userContactNumber: "", userPassword: "", userRoles: "member" });
            })
            .catch(error => console.error("Error adding user:", error));
    };

    // Delete a user
    const handleDeleteUser = (userId) => {
        const confirmDelete = window.confirm("Are you sure you want to delete this user?");
        if (!confirmDelete) return;
    
        axios.delete(`http://localhost:8080/api/users/delete/${userId}`)
            .then(() => fetchUsers())
            .catch(error => console.error("Error deleting user:", error));
    };

    // Edit a user
    const handleEditUser = (user) => {
        setEditingUser(user);
        setNewUser({
            userName: user.userName || "",
            userEmail: user.userEmail || "",
            userPassword: user.userPassword || "",
            userAddress: user.userAddress || "",
            userContactNumber: user.userContactNumber || "",
            userRoles: user.userRoles || "member",
        });
    };

    // Update a user
    const handleUpdateUser = () => {
        if (!editingUser) return;
        
        axios.put(`http://localhost:8080/api/users/update/${editingUser.userId}`, editingUser)
            .then(() => {
                fetchUsers();
                setEditingUser(null);
                setNewUser({ userName: "", userEmail: "", userAddress: "", userContactNumber: "", userPassword: "", userRoles: "member" });
            })
            .catch(error => console.error("Error updating user:", error));
    };

    return (
        <div className="form"> 
            <h2>Users List</h2>
            {errorMessage && <p style={{ color: "red" }}>{errorMessage}</p>}

            {/* Search Fields */}
            <div className="search-fields">
                <input 
                    type="text" 
                    name="userName" 
                    placeholder="Search by Name" 
                    value={searchTerm.userName} 
                    onChange={handleSearchChange} 
                />
                <input 
                    type="email" 
                    name="userEmail" 
                    placeholder="Search by Email" 
                    value={searchTerm.userEmail} 
                    onChange={handleSearchChange} 
                />
                <select 
                    name="userRoles" 
                    value={searchTerm.userRoles} 
                    onChange={handleSearchChange}
                >
                    <option value="">All Roles</option>
                    <option value="librarian">Librarian</option>
                    <option value="member">Member</option>
                </select>
            </div>

            {/* User List */}
            <ul className="user-list">
                {filteredUsers.map(user => (
                    <li key={user.userId}>
                        {user.userName} - {user.userEmail} ({user.userRoles})
                        <button onClick={() => handleEditUser(user)}>Edit</button>
                        <button onClick={() => handleDeleteUser(user.userId)}>Delete</button>
                    </li>
                ))}
            </ul>

            {/* Add / Edit User Form */}
            <h3>{editingUser ? "Edit User" : "Add User"}</h3>
            <input 
                type="text" 
                name="userName" 
                placeholder="Name" 
                value={editingUser ? editingUser.userName || "" : newUser.userName} 
                onChange={handleInputChange} 
            />
            <input 
                type="email" 
                name="userEmail" 
                placeholder="Email" 
                value={editingUser ? editingUser.userEmail || "" : newUser.userEmail} 
                onChange={handleInputChange} 
            />
            <input 
                type="password" 
                name="userPassword" 
                placeholder="Password" 
                value={editingUser ? editingUser.userPassword || "" : newUser.userPassword} 
                onChange={handleInputChange} 
            />
            <input 
                type="text" 
                name="userAddress" 
                placeholder="Address" 
                value={editingUser ? editingUser.userAddress || "" : newUser.userAddress} 
                onChange={handleInputChange} 
            />
            <input 
                type="text" 
                name="userContactNumber" 
                placeholder="Contact Number" 
                value={editingUser ? editingUser.userContactNumber || "" : newUser.userContactNumber} 
                onChange={handleInputChange} 
            />

            <select 
                name="userRoles" 
                value={editingUser ? editingUser.userRoles || "member" : newUser.userRoles} 
                onChange={handleInputChange}
            >
                <option value="librarian">Librarian</option>
                <option value="member">Member</option>
            </select>

            {editingUser ? (
                <button onClick={handleUpdateUser}>Update User</button>
            ) : (
                <button onClick={handleAddUser}>Add User</button>
            )}
        </div>
    );
};

export default UserManagement;
