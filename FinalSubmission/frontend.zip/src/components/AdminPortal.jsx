import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import "./AdminPortal.css"; // Import the CSS file

const AdminPortal = () => {
    const [adminName, setAdminName] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem("token");
        console.log("Stored Token:", token);  // Debugging: Check the token

        // Restrict access if not logged in (no token)
        if (!token) {
            alert("Access denied. Please log in.");
            navigate("/login");
            return;
        }

        // Optionally, get the admin name (if stored in localStorage or from an API)
        const admin = localStorage.getItem("adminName");
        setAdminName(admin || "Admin");
    }, [navigate]);

    return (
        <div className="admin-portal-container">
            <h2 className="admin-portal-title">Admin Portal</h2>
            <p className="welcome-message">Welcome, {adminName}!</p>
            <nav className="admin-portal-nav">
                <ul>
                    <li className="nav-item"><Link to="/book-management" className="nav-link">Manage Books</Link></li>
                    <li className="nav-item"><Link to="/user-management" className="nav-link">Manage Users</Link></li>
                </ul>
            </nav>
        </div>
    );
};

export default AdminPortal;
