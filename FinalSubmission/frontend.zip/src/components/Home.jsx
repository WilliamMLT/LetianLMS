import React from "react";
import { Link } from 'react-router-dom';
import './Home.css';

function Home() {
    return (
        <div>
          <h2>Welcome to the Library Management System</h2>
          <Link to="/register">
            <button>Register</button>
          </Link>
          <p></p>
          <Link to="/login">
            <button>Login</button>
          </Link>
        </div>
    );
}

export default Home;