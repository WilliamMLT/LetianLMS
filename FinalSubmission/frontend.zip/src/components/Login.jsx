import { useState } from "react";
import axios from "axios";
import { useNavigate } from 'react-router-dom';

function Login() {
    const [credentials, setCredentials] = useState({ userEmail: "", userPassword: ""});
    const navigate = useNavigate();

    const handleChange = (e) => {
        setCredentials({ ...credentials, [e.target.name]: e.target.value });
    };

    const getUserIdFromToken = (token) => {
        if (!token) return null;
        try {
            const decoded = JSON.parse(atob(token.split('.')[1])); // Decode the token payload
            return decoded.userId || null;
        } catch (error) {
            console.error("Failed to decode token:", error);
            return null;
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:8080/api/users/login", credentials);
    
            if (response.data.token) {
                // Store the JWT token in localStorage
                localStorage.setItem("token", response.data.token);
    
                // Store the user ID (optional)
                const userId = getUserIdFromToken(response.data.token);
                if (userId) {
                    localStorage.setItem("userId", userId); // Store userId
                }
    
                // Store the user name
                localStorage.setItem("userName", response.data.userName);
    
                // Store user email
                localStorage.setItem('userEmail', response.data.userEmail);
    
                // Check the role and navigate accordingly
                if (response.data.role === 'librarian') {
                    alert("Admin login successful!");
                    navigate("/admin-portal");
                } else if (response.data.role === 'member') {
                    alert("Member login successful!");
                    navigate("/member-portal");
                } else {
                    alert("Invalid role.");
                }
            } else {
                alert("Login failed! No token received.");
            }
        } catch (error) {
            console.error("Login error:", error);
            alert(error.response?.data?.message || "Invalid credentials");
        }
    };
    

    return (
        <form onSubmit={handleSubmit}>
            <input type="email" name="userEmail" placeholder="Email" onChange={handleChange} required />
            <input type="password" name="userPassword" placeholder="Password" onChange={handleChange} required />
            <button type="submit">Login</button>
        </form>
    );
}

export default Login;