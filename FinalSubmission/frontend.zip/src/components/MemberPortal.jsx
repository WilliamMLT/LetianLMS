import { useEffect, useState } from 'react';
import axios from 'axios';

function MemberPortal() {
  const [books, setBooks] = useState([]);
  const [borrowedBooks, setBorrowedBooks] = useState([]);
  const [error, setError] = useState(null);

  const token = localStorage.getItem('token');
  const userId = localStorage.getItem('userId');

  // Fetch books and borrowed books on load (only for members)
  useEffect(() => {
    if (!token || !userId) {
      // If no token or userId, redirect to login page
      window.location.href = '/login';
      return;
    }

    console.log("Fetching books for user:", userId); // Debugging step to check if the userId is being fetched correctly
    console.log("Token:", token); // Debugging step to check if the token is being fetched correctly

    // Fetch available books
    axios
      .get('http://localhost:8080/api/member/books', {
        headers: { 'Authorization': `Bearer ${token}` },
      })
      .then((response) => {
        setBooks(response.data);
      })
      .catch((error) => {
        console.error('Error fetching books:', error);
        setError('Failed to load books.');
      });

    // Fetch borrowed books
    axios
      .get(`http://localhost:8080/api/loans/borrowed/${userId}`, {
        headers: { 'Authorization': `Bearer ${token}` },
      })
      .then((response) => {
        console.log('Borrowed Books Response:', response.data); // Log the response for debugging
        setBorrowedBooks(Array.isArray(response.data) ? response.data : []);  // Ensure borrowedBooks is always an array
      })
      .catch((error) => {
        console.error('Error fetching borrowed books:', error);
        setError('Failed to load borrowed books.');
      });
  }, [token, userId]);

  const borrowBook = (bookId) => {
    if (!userId) {
      alert('User not authenticated');
      return;
    }

    // Check if the user has already borrowed this book
    const isAlreadyBorrowed = borrowedBooks.some((loan) => loan.book.bookId === bookId);

    if (isAlreadyBorrowed) {
      alert('You have already borrowed this book.');
      return; // Prevent further execution and API call
    }

    // Check if the book is already borrowed by someone else
    const isBookAlreadyBorrowed = borrowedBooks.some((loan) => loan.book.bookId === bookId);
    if (isBookAlreadyBorrowed) {
      alert('This book has already been borrowed by someone else.');
      return;
    }

    const book = books.find((book) => book.bookId === bookId);
    if (book.copiesAvailable <= 0) {
      alert('No copies available for borrowing.');
      return;
    }

    // Assuming the backend needs additional data like 'borrowedDate' and 'dueDate'
    const borrowedDate = new Date().toISOString();
    const dueDate = new Date(new Date().setDate(new Date().getDate() + 14)).toISOString(); // Set a due date for 14 days

    // Now including 'bookId' as a query parameter
    axios
      .post(
        `http://localhost:8080/api/loans/borrow?userId=${userId}&bookId=${bookId}`,  // Pass bookId and userId as query parameters
        { 
          status: 'BORROWED', 
          borrowedDate, 
          dueDate 
        },
        {
          headers: { 'Authorization': `Bearer ${token}` },
        }
      )
      .then((response) => {
        console.log("Book Borrowed Response:", response.data);
        if (response.data && response.data.loanId) {
          alert('Book borrowed successfully!');
          // Update borrowedBooks state to include the new borrowed book
          setBorrowedBooks(prevBooks => [...prevBooks, response.data]); // Append the new book to the existing borrowed books
        } else {
          alert('Failed to borrow book');
        }
      })
      .catch((error) => {
        console.error('Error borrowing book:', error);
        alert('Failed to borrow book');
      });
  };

  const returnBook = (loanId) => {
    axios
      .post(`http://localhost:8080/api/loans/return/${loanId}`, {}, {
        headers: { 'Authorization': `Bearer ${token}` },
      })
      .then((response) => {
        alert(response.data);
        // Refresh borrowed books after returning
        setBorrowedBooks(borrowedBooks.filter((loan) => loan.loanId !== loanId));
      })
      .catch((error) => {
        console.error('Error returning book:', error);
        alert('Failed to return book');
      });
  };

  return (
    <div className="container">
      <h1>Welcome to the Member Portal</h1>

      {error && <div className="error">{error}</div>}

      <h2>Available Books</h2>
      <ul className="book-list">
        {books.map((book) => {
          // Check if the book is borrowed (either by the current user or by someone else)
          const isBookBorrowed = borrowedBooks.some((loan) => loan.book.bookId === book.bookId);
          return (
            <li key={book.bookId}>
              <strong>{book.bookTitle}</strong> by {book.bookAuthor}
              <br /> ISBN: {book.bookIsbn} | Copies Available: {book.copiesAvailable}
              <br />
              {/* Show Borrow status */}
              <strong>Status: {isBookBorrowed ? 'Borrowed' : 'Available'}</strong>
              <br />
              <button 
                onClick={() => borrowBook(book.bookId)} 
                disabled={isBookBorrowed || book.copiesAvailable <= 0}
              >
                {isBookBorrowed ? 'Borrowed' : 'Borrow'}
              </button>
            </li>
          );
        })}
      </ul>

      <h2>Your Borrowed Books</h2>
      {borrowedBooks.length === 0 ? (
        <p>You have not borrowed any books.</p>
      ) : (
        <ul className="book-list">
          {borrowedBooks.map((loan) => (
            <li key={loan.loanId}>
              <strong>{loan.book?.bookTitle || 'Unknown Title'}</strong> by {loan.book?.bookAuthor || 'Unknown Author'}
              <br /> Borrowed on: {loan.borrowedDate} | Due Date: {loan.dueDate}
              <br />
              <button onClick={() => returnBook(loan.loanId)}>Return</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default MemberPortal;
