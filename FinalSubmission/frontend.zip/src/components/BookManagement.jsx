import { useEffect, useState } from "react";
import axios from "axios";
import "./BookManagement.css";

function BookManagement() {
  const [books, setBooks] = useState([]);
  const [filteredBooks, setFilteredBooks] = useState([]);
  const [bookDetails, setBookDetails] = useState({
    bookId: null,
    bookTitle: "",
    bookAuthor: "",
    bookIsbn: "",
    bookCategoryId: "",
    publicationYear: "",
  });

  const [bookNameFilter, setBookNameFilter] = useState("");
  const [error, setError] = useState(null);
  const [validationError, setValidationError] = useState(""); // Error for empty fields
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    fetchBooks();
  }, []);

  // Fetch all books
  const fetchBooks = () => {
    const token = localStorage.getItem("token");

    axios
      .get("http://localhost:8080/api/admin/books", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        setBooks(response.data);
        setFilteredBooks(response.data);
      })
      .catch((error) => {
        console.error("Error fetching books:", error.response?.data || error);
        setError("Failed to fetch books. Please try again later.");
      });
  };

  // Handle form input changes
  const handleChange = (e) => {
    setBookDetails({ ...bookDetails, [e.target.name]: e.target.value });
  };

  // Handle search filter change
  const handleFilterChange = (e) => {
    const filterText = e.target.value;
    setBookNameFilter(filterText);

    const token = localStorage.getItem("token");

    if (!filterText) {
      fetchBooks();
      return;
    }

    axios
      .get(`http://localhost:8080/api/admin/books/filter?name=${filterText}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        setFilteredBooks(response.data);
      })
      .catch((error) => {
        console.error("Error filtering books:", error.response?.data || error);
        setError("Failed to filter books. Please try again.");
      });
  };

  // Validate book details before submitting
  const validateBookDetails = () => {
    if (
      !bookDetails.bookTitle.trim() ||
      !bookDetails.bookAuthor.trim() ||
      !bookDetails.bookIsbn.trim() ||
      !bookDetails.bookCategoryId.trim() ||
      !bookDetails.publicationYear.toString().trim()
    ) {
      setValidationError("All fields must be filled.");
      return false;
    }
    setValidationError("");
    return true;
  };
  
  // Add a new book
  const handleAddBook = () => {
    if (!validateBookDetails()) return;

    const token = localStorage.getItem("token");

    axios
      .post("http://localhost:8080/api/admin/books", bookDetails, {
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        setBooks([...books, response.data]);
        setFilteredBooks([...books, response.data]);
        resetForm();
      })
      .catch((error) => {
        console.error("Error adding book:", error.response?.data || error);
        setError("Failed to add book. Please try again.");
      });
  };

  // Edit a book (set form fields for editing)
  const handleEditBook = (book) => {
    setBookDetails(book);
    setEditing(true);
  };

  // Update book details
  const handleUpdateBook = () => {
    if (!validateBookDetails()) return;

    const token = localStorage.getItem("token");

    axios
      .put(`http://localhost:8080/api/admin/books/${bookDetails.bookId}`, bookDetails, {
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      })
      .then(() => {
        setBooks(books.map((book) => (book.bookId === bookDetails.bookId ? bookDetails : book)));
        setFilteredBooks(filteredBooks.map((book) => (book.bookId === bookDetails.bookId ? bookDetails : book)));
        resetForm();
      })
      .catch((error) => {
        console.error("Error updating book:", error.response?.data || error);
        setError("Failed to update book. Please try again.");
      });
  };

  // Delete a book
  const handleDeleteBook = (bookId) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this book?");
    if (!confirmDelete) return;

    const token = localStorage.getItem("token");

    axios
      .delete(`http://localhost:8080/api/admin/books/${bookId}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then(() => {
        const updatedBooks = books.filter((book) => book.bookId !== bookId);
        setBooks(updatedBooks);
        setFilteredBooks(updatedBooks);
      })
      .catch((error) => {
        console.error("Error deleting book:", error.response?.data || error);
        setError("Failed to delete book. Please try again.");
      });
  };

  // Reset form fields
  const resetForm = () => {
    setBookDetails({
      bookId: null,
      bookTitle: "",
      bookAuthor: "",
      bookIsbn: "",
      bookCategoryId: "",
      publicationYear: "",
    });
    setValidationError("");
    setEditing(false);
  };

  return (
    <div className="container">
      <h1>Book Management</h1>

      {error && <div className="error-message">{error}</div>}

      <div className="search">
        <label htmlFor="book-name-filter" className="search-label">
          Book Title:
        </label>
        <input
          id="book-name-filter"
          type="text"
          placeholder="Search by book name"
          value={bookNameFilter}
          onChange={handleFilterChange}
        />
      </div>

      <div className="form">
        <input type="text" name="bookTitle" placeholder="Title" value={bookDetails.bookTitle} onChange={handleChange} required />
        <input type="text" name="bookAuthor" placeholder="Author" value={bookDetails.bookAuthor} onChange={handleChange} required />
        <input type="text" name="bookIsbn" placeholder="ISBN" value={bookDetails.bookIsbn} onChange={handleChange} />
        <input type="text" name="bookCategoryId" placeholder="Category ID" value={bookDetails.bookCategoryId} onChange={handleChange} />
        <input type="number" name="publicationYear" placeholder="Publication Year" value={bookDetails.publicationYear} onChange={handleChange} />

        {/* Display validation error if title or author is empty */}
        {validationError && <div className="error-message">{validationError}</div>}

        {editing ? (
          <button onClick={handleUpdateBook}>Update Book</button>
        ) : (
          <button onClick={handleAddBook}>Add Book</button>
        )}
        {editing && <button onClick={resetForm}>Cancel</button>}
      </div>

      <ul className="book-list">
        {filteredBooks.length > 0 ? (
          filteredBooks.map((book) => (
            <li key={book.bookId}>
              <strong>{book.bookTitle}</strong> by {book.bookAuthor}
              <br />
              ISBN: {book.bookIsbn} | Category ID: {book.bookCategoryId}
              <br />
              Published: {book.publicationYear}
              <br />
              <button onClick={() => handleEditBook(book)}>Edit</button>
              <button onClick={() => handleDeleteBook(book.bookId)}>Delete</button>
            </li>
          ))
        ) : (
          <p>No books found.</p>
        )}
      </ul>
    </div>
  );
}

export default BookManagement;
