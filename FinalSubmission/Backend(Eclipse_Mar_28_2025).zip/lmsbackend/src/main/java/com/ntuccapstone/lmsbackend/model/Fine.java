package com.ntuccapstone.lmsbackend.model;

import java.math.BigDecimal;
import java.time.LocalDate; // Use LocalDate instead of String
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "tbl_fines")
public class Fine {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int fineId;

    private int userId;
    private int loanId;
    private BigDecimal fineAmount;
    private LocalDate dueDate; // Use LocalDate instead of String

    @Enumerated(EnumType.STRING)
    private FineStatus status;

    // Constructor
    public Fine() {}

    public Fine(int fineId, int userId, int loanId, BigDecimal fineAmount, LocalDate dueDate, FineStatus status) {
        this.fineId = fineId;
        this.userId = userId;
        this.loanId = loanId;
        this.fineAmount = fineAmount;
        this.dueDate = dueDate;
        this.status = status;
    }

    // Getters and setters
    public int getFineId() {
        return fineId;
    }

    public void setFineId(int fineId) {
        this.fineId = fineId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getLoanId() {
        return loanId;
    }

    public void setLoanId(int loanId) {
        this.loanId = loanId;
    }

    public BigDecimal getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(BigDecimal fineAmount) {
        this.fineAmount = fineAmount;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public FineStatus getStatus() {
        return status;
    }

    public void setStatus(FineStatus status) {
        this.status = status;
    }
}

enum FineStatus {
    UNPAID, PAID
}