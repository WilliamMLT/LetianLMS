package com.ntuccapstone.lmsbackend.controller;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.ntuccapstone.lmsbackend.model.Loan;
import com.ntuccapstone.lmsbackend.model.LoanStatus;
import com.ntuccapstone.lmsbackend.repository.LoanRepository;
import com.ntuccapstone.lmsbackend.service.LoanService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@RestController
@RequestMapping("/api/loans")
public class LoanController {

    @Autowired
    private LoanService loanService;
    @Autowired
    private LoanRepository loanRepository;  // Inject LoanRepository instance
    
    // Borrow a book (only accessible by member)
    @PostMapping("/borrow")
    public String borrowBook(@RequestHeader(value = "Authorization", required = false) String authHeader, 
                             @RequestParam int userId, @RequestParam int bookId) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return "Authorization header missing or invalid.";
        }

        String token = authHeader.replace("Bearer ", "");
        String role = extractUserRole(token);

        if (role == null || !"member".equals(role)) {
            return "Access denied. Only members can borrow books.";
        }

        return loanService.borrowBook(userId, bookId);
    }

    // Return a book (only accessible by member)
    @PostMapping("/return")
    public String returnBook(@RequestHeader(value = "Authorization", required = false) String authHeader, 
                             @RequestParam int loanId) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return "Authorization header missing or invalid.";
        }

        String token = authHeader.replace("Bearer ", "");
        String role = extractUserRole(token);

        if (role == null || !"member".equals(role)) {
            return "Access denied. Only members can return books.";
        }

        return loanService.returnBook(loanId);
    }

    // Get the count of borrowed books by user
    @GetMapping("/borrowed/{userId}")
    public int countBorrowedBooks(@PathVariable int userId) {
        return loanService.countBorrowedBooks(userId);
    }

    // Get the count of overdue books by user
    @GetMapping("/overdue/{userId}")
    public int countOverdueBooks(@PathVariable int userId) {
        return loanService.countOverdueBooks(userId);
    }

    // Get borrowed books for a specific user
    @GetMapping("/loans/borrowed/{userId}")
    public List<Loan> getBorrowedBooks(@RequestHeader(value = "Authorization", required = false) String authHeader,
                                       @PathVariable("userId") int userId) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return null;
        }

        String token = authHeader.replace("Bearer ", "");
        String role = extractUserRole(token);

        if (role == null || !"member".equals(role)) {
            return null;
        }

        // Fetch loans for the user with a "BORROWED" status
        return loanRepository.findByUser_UserIdAndStatus(userId, LoanStatus.BORROWED);
    }

    private String extractUserRole(String token) {
        try {
            Claims claims = Jwts.parser()
                .setSigningKey(Base64.getDecoder().decode("1f6a735d9be8819352b17cfd6c9115b8ec1ef5a9f5e755f14d364c57c573be34"))
                .build()
                .parseClaimsJws(token)
                .getBody();
            return claims.get("role", String.class);
        } catch (Exception e) {
            return null;
        }
    }
}
