package com.ntuccapstone.lmsbackend.model;

public enum UserRole {
    librarian, 
    member
}