package com.ntuccapstone.lmsbackend.model;

import java.time.LocalDate;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name = "tbl_users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId;
    private String userName;
    private String userEmail;
    private String userAddress;
    private String userContactNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserRole userRoles; // Use an enum for user roles

    @Column(nullable = false)
    private String userPassword;

    @Column(name = "outstanding_fines")
    private double outstandingFines;

    // Constructors, getters, and setters
    public User() {}

    public User(int userId, String userName, String userEmail, String userAddress, String userContactNumber,
            UserRole userRoles, String userPassword, LocalDate userCreatedDate, double outstandingFines) {
	    this.userId = userId;
	    this.userName = userName;
	    this.userEmail = userEmail;
	    this.userAddress = userAddress;
	    this.userContactNumber = userContactNumber;
	    this.userRoles = userRoles;
	    this.userPassword = userPassword;
	    this.outstandingFines = outstandingFines;
}

    // Getters and setters
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getUserContactNumber() {
        return userContactNumber;
    }

    public void setUserContactNumber(String userContactNumber) {
        this.userContactNumber = userContactNumber;
    }

    public UserRole getUserRoles() {
        return userRoles;
    }

    public void setUserRoles(UserRole userRoles) {
        this.userRoles = userRoles;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public double getOutstandingFines() {
        return outstandingFines;
    }

    public void setOutstandingFines(double outstandingFines) {
        this.outstandingFines = outstandingFines;
    }
}