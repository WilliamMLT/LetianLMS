package com.ntuccapstone.lmsbackend.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ntuccapstone.lmsbackend.model.User;
import com.ntuccapstone.lmsbackend.repository.UserRepository;
import com.ntuccapstone.lmsbackend.service.UserService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;


@RestController
@RequestMapping("/api/users") // localhost:8080/api/users
@CrossOrigin(origins = "http://localhost:5173") // Integration with frontend (Vite)
public class UserController {

    @Autowired
    private UserService userService;
    
    public UserController(UserService userService) {
        this.userService = userService;
    }
    
    // GET: Fetch all users
    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    // GET: current login-user's details
    @GetMapping("/me")
    public ResponseEntity<User> getCurrentUser(@RequestHeader("Authorization") String token) {
        // Extract the token from the Authorization header
        String tokenWithoutBearer = token.replace("Bearer ", "");  // Remove "Bearer " prefix if it exists
        Claims claims = Jwts.parser()
                            .setSigningKey(SECRET_KEY)
                            .build()
                            .parseClaimsJws(tokenWithoutBearer)
                            .getBody();
        
        String userEmail = claims.getSubject(); // Get the user's email from the token

        // Fetch the user from the database based on the email stored in the token
        Optional<User> userOptional = userService.getUserByEmail(userEmail);

        // Check if user exists
        if (!userOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        // Return the user details as response
        return ResponseEntity.ok(userOptional.get());
    }
    
    // POST: Add a new user
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        // Validate user input (email, password length, etc.)
        if (user.getUserEmail() == null || !user.getUserEmail().contains("@")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid email format.");
        }

        if (user.getUserPassword().length() < 6) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Password must be at least 6 characters.");
        }

        // Check if user already exists (e.g., using email)
        if (userService.existsByEmail(user.getUserEmail())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("User with this email already exists.");
        }

        // Proceed to register the user
        try {
            userService.registerUser(user);
            return ResponseEntity.status(HttpStatus.CREATED).body("User registered successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error during registration!");
        }
    }
    
    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody User loginUser) {
        if (loginUser.getUserEmail() == null || loginUser.getUserEmail().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is required.");
        }
        
        // Fetch the user by email from the database
        Optional<User> userOptional = userService.getUserByEmail(loginUser.getUserEmail());
        
        // If the user is not found or password doesn't match, return unauthorized response (401 Unauthorized)
        if (!userOptional.isPresent() || !loginUser.getUserPassword().equals(userOptional.get().getUserPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
        
        // Retrieve the actual user object from the optional wrapper
        User user = userOptional.get();

        // Generate JWT token for authentication (this token will be used in future API requests to validate the user's identity)
        String token = generateToken(user);
        
        // Return the token, role, and user name in the response
        return ResponseEntity.ok().body("{\"token\":\"" + token + "\", \"role\":\"" + user.getUserRoles().name() + "\", \"userName\":\"" + user.getUserName() + "\"}");
    }

    
    @DeleteMapping("/delete/{userId}")
    public ResponseEntity<String> deleteUser(@PathVariable int userId) {
        try {
            userService.deleteUser(userId);
            return ResponseEntity.ok("User deleted successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting user.");
        }
    }
    
    @PutMapping("/update/{userId}")
    public ResponseEntity<String> updateUser(@PathVariable int userId, @RequestBody User updatedUser) {
        Optional<User> existingUser = userService.getUserById(userId);

        if (!existingUser.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found.");
        }

        User user = existingUser.get();
        user.setUserName(updatedUser.getUserName());
        user.setUserEmail(updatedUser.getUserEmail());
        user.setUserPassword(updatedUser.getUserPassword());
        user.setUserAddress(updatedUser.getUserAddress());
        user.setUserContactNumber(updatedUser.getUserContactNumber());
        user.setUserRoles(updatedUser.getUserRoles());

        userService.updateUser(user);
        return ResponseEntity.ok("User updated successfully.");
    }
    
    private String SECRET_KEY = "1f6a735d9be8819352b17cfd6c9115b8ec1ef5a9f5e755f14d364c57c573be34";

    private String generateToken(User user) {
        return Jwts.builder()
                .setSubject(user.getUserEmail())  // Token subject is the user email
                .claim("userId", user.getUserId())  // Include userId in the token
                .claim("role", user.getUserRoles().name()) // Add user role as a claim
                .setIssuedAt(new Date())          // Token issue date
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10)) // 10-hour expiration
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)
                .compact();
    }
    // Method to extract user role from JWT token
    private String extractUserRole(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .build()
                .parseClaimsJws(token)
                .getBody();
        return claims.get("role", String.class); // Extract role from claims
    }
}
