package com.ntuccapstone.lmsbackend.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ntuccapstone.lmsbackend.model.Book;
import com.ntuccapstone.lmsbackend.model.Loan;
import com.ntuccapstone.lmsbackend.model.LoanStatus;
import com.ntuccapstone.lmsbackend.model.User;

@Repository
public interface LoanRepository extends JpaRepository<Loan, Integer> {

    // Counts the number of loans for a user with a specific status.
    int countByUserUserIdAndStatus(int userId, LoanStatus status);
    
    // Counts the number of overdue loans for a user.
    int countByUserUserIdAndDueDateBeforeAndStatus(int userId, LocalDate dueDate, LoanStatus status);

    // Finds an active loan for a specific user and book.
    // Returns an Optional, assuming each book should have only one loan per user at a time.
    Optional<Loan> findByUserAndBookAndStatus(User user, Book book, LoanStatus status);
    
    // Retrieves all loans for a user with a specific status.
    List<Loan> findByUser_UserIdAndStatus(int userId, LoanStatus status);
}