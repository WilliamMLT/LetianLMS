package com.ntuccapstone.lmsbackend.repository;

import com.ntuccapstone.lmsbackend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    // Find user by email
    Optional<User> findByUserEmail(String userEmail);

    // Check if a user with the given email exists
    boolean existsByUserEmail(String userEmail);
    
    //@Query("SELECT u.outstandingFines FROM User u WHERE u.userId = :userId")
    //Optional<Double> getOutstandingFines(@Param("userId") int userId);
}