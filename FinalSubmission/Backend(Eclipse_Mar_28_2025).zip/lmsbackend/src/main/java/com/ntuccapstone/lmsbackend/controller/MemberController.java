package com.ntuccapstone.lmsbackend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ntuccapstone.lmsbackend.service.BookService;

@RestController
@RequestMapping("/api/member/books") // Endpoint for members to view books
@CrossOrigin(origins = "http://localhost:5173") // Frontend URL
public class MemberController {

    @Autowired
    private BookService bookService;

    @GetMapping
    public ResponseEntity<?> getBooksForMembers(@RequestHeader("Authorization") String authHeader) {
        String token = authHeader.replace("Bearer ", "");
        
        // Optionally, validate the token here (e.g., extract role or check validity)
        // In this case, you are just fetching books for all members.

        return ResponseEntity.ok(bookService.getAllBooks()); // Return all books for members
    }
}
