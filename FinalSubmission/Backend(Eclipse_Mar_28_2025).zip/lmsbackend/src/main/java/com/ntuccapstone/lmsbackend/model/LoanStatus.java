package com.ntuccapstone.lmsbackend.model;

public enum LoanStatus {
    BORROWED, RETURNED, OVERDUE;
	
	public static LoanStatus fromString(String status) {
        switch (status.toLowerCase()) {
            case "borrowed":
                return BORROWED;
            case "returned":
                return RETURNED;
            case "overdue":
                return OVERDUE;
            default:
                throw new IllegalArgumentException("Unknown status: " + status);
        }
    }
}