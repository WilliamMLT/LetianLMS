package com.ntuccapstone.lmsbackend.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity(name = "tbl_loans")
public class Loan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int loanId;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "book_id")
    private Book book;

//    @ManyToOne
//    @JoinColumn(name = "copy_id")
//    private BookCopy bookCopy;

    private LocalDate borrowedDate;
    @Column(nullable = false)
    private LocalDate dueDate;
    private LocalDate returnDate;

    @Enumerated(EnumType.STRING)
    private LoanStatus status; // Use an enum for status

    @Column(name = "renewal_count")  // Make sure the column name matches the one in your database
    private Integer renewalCount;  // Use the correct field name here
    
    public Loan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Loan(int loanId, User user, Book book, LocalDate borrowedDate, LocalDate dueDate, LocalDate returnDate,
			LoanStatus status, Integer renewalCount) {
		super();
		this.loanId = loanId;
		this.user = user;
		this.book = book;
		this.borrowedDate = borrowedDate;
		this.dueDate = dueDate;
		this.returnDate = returnDate;
		this.status = status;
		this.renewalCount = renewalCount;
	}

	// Getters and setters
    public int getLoanId() {
        return loanId;
    }

    public void setLoanId(int loanId) {
        this.loanId = loanId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public LocalDate getBorrowedDate() {
        return borrowedDate;
    }

    public void setBorrowedDate(LocalDate borrowedDate) {
        this.borrowedDate = borrowedDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public LoanStatus getStatus() {
        return status;
    }

    public void setStatus(LoanStatus status) {
        this.status = status;
    }

	public Integer getRenewalCount() {
		return renewalCount;
	}

	public void setRenewalCount(Integer renewalCount) {
		this.renewalCount = renewalCount;
	}


}

