package com.ntuccapstone.lmsbackend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ntuccapstone.lmsbackend.model.Book;
import com.ntuccapstone.lmsbackend.repository.BookRepository;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    // Add a new book
    public Book addBook(Book book) {
        // If necessary, set default values for any missing fields
        if (book.getBookCategoryId() == 0) {
            book.setBookCategoryId(1);  // Default category ID or handle it as needed
        }
        
        // Save and return the saved book (with auto-generated ID)
        return bookRepository.save(book);
    }

    // Get all books
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }
    // Method to find books by name
    public List<Book> getBooksByName(String bookTitle) {
        return bookRepository.findByBookTitleContainingIgnoreCase(bookTitle);
    }
    
    public Book updateBook(Book book) {
        return bookRepository.save(book); // Save updated book details
    }

    public void deleteBook(Long bookId) {
        bookRepository.deleteById(bookId.intValue()); // Convert Long to Integer
    }
}