package com.ntuccapstone.lmsbackend.controller;

import java.util.List;
import java.util.Date;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ntuccapstone.lmsbackend.model.Book;
import com.ntuccapstone.lmsbackend.service.BookService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@RestController
@RequestMapping("/api/admin/books") // localhost:5173/api/admin/books, // Librarians manage books here
@CrossOrigin(origins = "http://localhost:5173") // Integration with frontend (Vite)
public class BookController {
    
    @Autowired
    private BookService bookService;
    
    private final String SECRET_KEY = "1f6a735d9be8819352b17cfd6c9115b8ec1ef5a9f5e755f14d364c57c573be34"; // Same as UserController

    private String extractUserRole(String token) {
        try {
            Claims claims = Jwts.parser()
                .setSigningKey(Base64.getDecoder().decode(SECRET_KEY)) // Decode the secret key
                .build()
                .parseClaimsJws(token)
                .getBody();
            return claims.get("role", String.class); // Extract user role from JWT
        } catch (Exception e) {
            return null; // Return null if token is invalid
        }
    }

    // Get all books (only accessible by librarian)
    @GetMapping
    public ResponseEntity<?> getBooks(@RequestHeader(value = "Authorization", required = false) String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Authorization header missing or invalid.");
        }

        String token = authHeader.replace("Bearer ", "");
        String role = extractUserRole(token);

        if (role == null || !"librarian".equals(role)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied. Only librarians can manage books.");
        }

        return ResponseEntity.ok(bookService.getAllBooks());
    }

    // Add a new book (only accessible by librarian)
    @PostMapping
    public ResponseEntity<?> addBook(@RequestHeader(value = "Authorization", required = false) String authHeader, @RequestBody Book book) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Authorization header missing or invalid.");
        }

        String token = authHeader.replace("Bearer ", "");
        String role = extractUserRole(token);

        if (role == null || !"librarian".equals(role)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied. Only librarians can add books.");
        }

        return ResponseEntity.ok(bookService.addBook(book));
    }

    // Filter books by title (only accessible by librarian)
    @GetMapping("/filter")
    public ResponseEntity<?> filterBooks(@RequestHeader(value = "Authorization", required = false) String authHeader, @RequestParam("name") String bookTitle) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Authorization header missing or invalid.");
        }

        String token = authHeader.replace("Bearer ", "");
        String role = extractUserRole(token);

        if (role == null || !"librarian".equals(role)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied. Only librarians can filter books.");
        }

        return ResponseEntity.ok(bookService.getBooksByName(bookTitle));
    }
 // Update a book (only accessible by librarian)
    @PutMapping("/{bookId}")
    public ResponseEntity<?> updateBook(
        @RequestHeader(value = "Authorization", required = false) String authHeader,
        @PathVariable Long bookId,
        @RequestBody Book book) {
        
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Authorization header missing or invalid.");
        }

        String token = authHeader.replace("Bearer ", "");
        String role = extractUserRole(token);

        if (role == null || !"librarian".equals(role)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied. Only librarians can update books.");
        }

        book.setBookId(bookId.intValue()); // Ensure correct ID is set
        return ResponseEntity.ok(bookService.updateBook(book));
    }

    // Delete a book (only accessible by librarian)
    @DeleteMapping("/{bookId}")
    public ResponseEntity<?> deleteBook(
        @RequestHeader(value = "Authorization", required = false) String authHeader,
        @PathVariable Long bookId) {
        
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Authorization header missing or invalid.");
        }

        String token = authHeader.replace("Bearer ", "");
        String role = extractUserRole(token);

        if (role == null || !"librarian".equals(role)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied. Only librarians can delete books.");
        }

        bookService.deleteBook(bookId);
        return ResponseEntity.ok("Book deleted successfully.");
    }
}
