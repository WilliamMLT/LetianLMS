package com.ntuccapstone.lmsbackend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ntuccapstone.lmsbackend.model.Book;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {
	List<Book> findByBookTitleContainingIgnoreCase(String bookTitle); //IgnoreCase ensures the search is case-insensitive.Containing makes it a partial match (you can type any part of the book's name).

}
