package com.ntuccapstone.lmsbackend.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ntuccapstone.lmsbackend.model.Book;
import com.ntuccapstone.lmsbackend.model.Loan;
import com.ntuccapstone.lmsbackend.model.LoanStatus;
import com.ntuccapstone.lmsbackend.model.User;
import com.ntuccapstone.lmsbackend.repository.BookRepository;
import com.ntuccapstone.lmsbackend.repository.LoanRepository;
import com.ntuccapstone.lmsbackend.repository.UserRepository;

@Service
public class LoanService {

    @Autowired
    private LoanRepository loanRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private UserRepository userRepository;

    // Borrow a book
    public String borrowBook(int userId, int bookId) {
        Optional<Book> bookOpt = bookRepository.findById(bookId);
        Optional<User> userOpt = userRepository.findById(userId);

        if (bookOpt.isEmpty() || userOpt.isEmpty()) {
            return "Book or User not found";
        }

        Book book = bookOpt.get();
        User user = userOpt.get();

        // Check if the user has already borrowed this book
        Optional<Loan> existingLoanOpt = loanRepository.findByUserAndBookAndStatus(user, book, LoanStatus.BORROWED);
        if (existingLoanOpt.isPresent()) {
            return "You have already borrowed this book.";
        }

        // Create a new loan record
        Loan loan = new Loan();
        loan.setUser(user);
        loan.setBook(book);
        loan.setBorrowedDate(LocalDate.now());
        loan.setDueDate(LocalDate.now().plusWeeks(2)); // 2-week borrowing period
        loan.setStatus(LoanStatus.BORROWED);

        loanRepository.save(loan);

        return "Book borrowed successfully";
    }

    // Return a book
    public String returnBook(int loanId) {
        Optional<Loan> loanOpt = loanRepository.findById(loanId);

        if (loanOpt.isEmpty()) {
            return "Loan record not found";
        }

        Loan loan = loanOpt.get();

        if (loan.getStatus() != LoanStatus.BORROWED) {
            return "This book has already been returned";
        }

        // Mark book as returned
        loan.setStatus(LoanStatus.RETURNED);
        loan.setReturnDate(LocalDate.now());

        loanRepository.save(loan);

        return "Book returned successfully";
    }

    // Get borrowed books for a user
    public List<Loan> getBorrowedBooksByUserId(int userId) {
        return loanRepository.findAll().stream()
                .filter(loan -> loan.getUser().getUserId() == userId && loan.getStatus() == LoanStatus.BORROWED)
                .collect(Collectors.toList());
    }

    // Count the number of books currently borrowed by a user
    public int countBorrowedBooks(int userId) {
        return (int) loanRepository.findAll().stream()
                .filter(loan -> loan.getUser().getUserId() == userId && loan.getStatus() == LoanStatus.BORROWED)
                .count();
    }

    // Count the number of overdue books for a user
    public int countOverdueBooks(int userId) {
        return (int) loanRepository.findAll().stream()
                .filter(loan -> loan.getUser().getUserId() == userId 
                        && loan.getStatus() == LoanStatus.BORROWED
                        && loan.getDueDate().isBefore(LocalDate.now()))
                .count();
    }
}
