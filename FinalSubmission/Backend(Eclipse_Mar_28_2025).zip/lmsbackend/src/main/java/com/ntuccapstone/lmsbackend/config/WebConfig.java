package com.ntuccapstone.lmsbackend.config; // Define the package for the configuration class

//Import necessary classes for CORS configuration and WebMvcConfigurer
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

//@Configuration annotation marks this class as a configuration class. 
//It indicates that this class contains Spring beans and settings to be used in the Spring application context.
@Configuration
public class WebConfig implements WebMvcConfigurer {
	
	// @Override annotation indicates that this method is overriding a method from the WebMvcConfigurer interface.
    // The method addCorsMappings is used to configure CORS settings for the web application.
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**").allowedOrigins("http://localhost:5173");
    }
}