package com.ntuccapstone.lmsbackend.service;

import com.ntuccapstone.lmsbackend.model.User;
import com.ntuccapstone.lmsbackend.model.UserRole;
import com.ntuccapstone.lmsbackend.repository.UserRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Check if user already exists by email
    public boolean existsByEmail(String email) {
        return userRepository.existsByUserEmail(email);
    }

    // Register user and save to the database
    public void registerUser(User user) {
        // Hash password using BCrypt
//        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//        String hashedPassword = passwordEncoder.encode(user.getUserPassword()); //Hash Password
//        user.setUserPassword(hashedPassword); // Store hashed password

        // Set default role (you can customize this)
        if (user.getUserRoles() == null) {
            user.setUserRoles(UserRole.member);  // Default role if not provided
        }

        // Save user to database
        userRepository.save(user);
    }
    
    public void deleteUser(int userId) {
        userRepository.deleteById(userId);
    }
    
    public void updateUser(User user) {
        userRepository.save(user);
    }

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByUserEmail(email);  // Fetch user by email
    }
    
    public Optional<User> getUserById(int userId) {
        return userRepository.findById(userId);
    }
}
