// This code defines a CORS (Cross-Origin Resource Sharing) configuration for a Spring Boot application.
package com.ntuccapstone.lmsbackend.config;

//Import necessary classes for configuration and CORS filter
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.List;

//@Configuration annotation marks this class as a configuration class that Spring will use to set up the application context
@Configuration
public class CorsConfig {
	// @Bean annotation tells Spring to treat this method as a bean definition, meaning the returned object will be managed by the Spring container
	@Bean
    public CorsFilter corsFilter() {
		 // Create a new CorsConfiguration object that holds all the configuration details for CORS
        CorsConfiguration config = new CorsConfiguration();
        
        // Set the allowed origins (i.e., the sources from which requests are accepted)
        // Here, it's allowing only the frontend running on http://localhost:5173 to access the backend
        config.setAllowedOrigins(List.of("http://localhost:5173"));  // Allow frontend origin
        
        // Set the allowed HTTP methods for cross-origin requests. This includes the typical methods used in CRUD operations
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE"));
        
        // Set the allowed headers. These are the headers that the frontend can send in the request.
        // Authorization header is typically used for passing authentication tokens.
        config.setAllowedHeaders(List.of("Authorization", "Content-Type"));
        
        // Allow sending credentials (like cookies or authentication tokens) along with requests.
        // This is needed when the frontend and backend are on different origins and you need to send user data (e.g., session data).
        config.setAllowCredentials(true);

        // Create a source for the CORS configuration. This will map the CORS configuration to specific URL patterns
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        
        // Register the CORS configuration to apply to all URL patterns (/** means all URLs)
        source.registerCorsConfiguration("/**", config);
        
        // Return a new CorsFilter object which applies the registered CORS configuration to all incoming HTTP requests
        return new CorsFilter(source);
    }
}

