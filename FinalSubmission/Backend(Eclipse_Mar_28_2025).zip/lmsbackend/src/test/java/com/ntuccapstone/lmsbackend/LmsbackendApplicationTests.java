package com.ntuccapstone.lmsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LmsbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
